// send request to with the correct headers to login the user

/*
"bresoltuion": "1920x1080"
"image1": "Backpack.png"
*/


// HEADERS:
username = "s77478";
password = "cc20040729";
os = "Unknown";
userdn = "";
code = "santafe";
Browser = "Firefox";
Resolution = "1920x1080";

login_url = "https://launchpad.classlink.com/login";

console.log(window.location.href)

if (window.location.href === "https://www.sfps.info/students___parents/canvas") {

  window.location = "https://launchpad.classlink.com/santafe"

}
// csrf = '';
// connect_sid = '';

// function get_csrf_cookie() {
//   var getting = browser.cookies.get({
//     url: "https://launchpad.classlink.com/",
//     name: "_csrf"
//   });
//   getting.then(function (cookie) { csrf = cookie.value; });
// }

// send post request to login_url with HEADERS
function login() {
  post = new XMLHttpRequest();

  post.open("POST", login_url, true);
  post.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  post.send("username=" + username + "&password=" + password + "&code=" + code);
  console.log(post);
  token = post.token;
  twofactor_url = new XMLHttpRequest();
  twofactor_url.open("POST", "https://launchpad.classlink.com/" + token, true);
  twofactor_url.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  twofactor_url.send("bresolution=1920x1080&image1=Backpack.png");
  console.log(twofactor_url.status);
}

login();